package com.yellow.eq

import android.media.audiofx.Visualizer
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Listens to the phone's audio output mix (session 0) through Android's Visualizer
 * and turns the FFT into NB band levels (0..1). It only reads frequency levels;
 * no audio is recorded or stored.
 */
class AudioAnalyzer {

    private var vis: Visualizer? = null
    private var fft = ByteArray(0)
    private var mags = FloatArray(0)
    private val lo = FloatArray(EqView.NB)
    private val hi = FloatArray(EqView.NB)

    var lastError: String? = null
    val running: Boolean get() = vis != null

    fun start(): Boolean {
        if (vis != null) return true
        return try {
            val v = Visualizer(0)
            try {
                v.setEnabled(false)
                val range = Visualizer.getCaptureSizeRange()
                v.setCaptureSize(min(1024, range[1]).coerceAtLeast(range[0]))
                try {
                    v.setScalingMode(Visualizer.SCALING_MODE_NORMALIZED)
                } catch (e: Exception) {
                    // not important
                }
                v.setEnabled(true)
            } catch (e: Exception) {
                try { v.release() } catch (e2: Exception) { }
                throw e
            }
            val size = v.getCaptureSize()
            fft = ByteArray(size)
            mags = FloatArray(size / 2)
            var sr = v.getSamplingRate() / 1000f
            if (sr <= 0f) sr = 44100f
            val binHz = sr / size
            val fMin = 40.0
            val fMax = min(12000.0, sr * 0.45)
            for (i in 0 until EqView.NB) {
                val f0 = fMin * (fMax / fMin).pow(i.toDouble() / EqView.NB)
                val f1 = fMin * (fMax / fMin).pow((i + 1).toDouble() / EqView.NB)
                lo[i] = (f0 / binHz).toFloat()
                hi[i] = (f1 / binHz).toFloat()
            }
            vis = v
            lastError = null
            true
        } catch (e: Exception) {
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
            vis = null
            false
        }
    }

    fun stop() {
        val v = vis ?: return
        vis = null
        try { v.setEnabled(false) } catch (e: Exception) { }
        try { v.release() } catch (e: Exception) { }
    }

    private fun magAt(x: Float): Float {
        val k = x.toInt().coerceIn(0, mags.size - 1)
        val k2 = min(k + 1, mags.size - 1)
        val fr = (x - k).coerceIn(0f, 1f)
        return mags[k] + (mags[k2] - mags[k]) * fr
    }

    /** Fills [out] with band levels. Returns false only if the audio engine broke. */
    fun read(out: FloatArray): Boolean {
        val v = vis ?: return false
        try {
            val rc = v.getFft(fft)
            if (rc != Visualizer.SUCCESS) {
                java.util.Arrays.fill(out, 0f)
                return true
            }
        } catch (e: Exception) {
            lastError = e.javaClass.simpleName + ": " + (e.message ?: "")
            stop()
            return false
        }
        val n = mags.size
        mags[0] = abs(fft[0].toInt()).toFloat()
        for (k in 1 until n) {
            val re = fft[2 * k].toInt()
            val im = fft[2 * k + 1].toInt()
            mags[k] = hypot(re.toDouble(), im.toDouble()).toFloat()
        }
        for (i in 0 until EqView.NB) {
            val l = lo[i]
            val h = hi[i]
            val m: Float
            if (h - l < 1.2f) {
                m = magAt((l + h) / 2f)
            } else {
                var best = 0f
                val a = l.toInt().coerceIn(1, n - 1)
                val b = h.toInt().coerceIn(a, n - 1)
                for (k in a..b) best = max(best, mags[k])
                m = best
            }
            val lg = log10(1.0 + m) / 2.0
            val x = ((lg - 0.12) / 0.88).coerceAtLeast(0.0)
            val tilt = 1.0 + 1.3 * i / EqView.NB
            out[i] = (x * tilt).coerceIn(0.0, 1.0).toFloat()
        }
        return true
    }
}
