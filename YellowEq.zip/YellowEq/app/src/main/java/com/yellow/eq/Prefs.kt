package com.yellow.eq

import android.content.Context
import android.content.SharedPreferences

/** All user settings live here (shared by the app screen and the background service). */
class Prefs(ctx: Context) {
    val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("yellow_eq", Context.MODE_PRIVATE)

    companion object {
        const val SCOPE_ALL = 0
        const val SCOPE_HOME = 1
        const val SCOPE_LOCK = 2
        val SCOPES = listOf("Everywhere", "Home screen", "Lock screen")
    }

    var enabled: Boolean
        get() = sp.getBoolean("enabled", false)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    var style: Int
        get() = sp.getInt("style", 0)
        set(v) { sp.edit().putInt("style", v).apply() }

    var color: Int
        get() = sp.getInt("color", 0xFFFFD400.toInt())
        set(v) { sp.edit().putInt("color", v).apply() }

    /** Ring radius in dp. */
    var size: Int
        get() = sp.getInt("size", 11)
        set(v) { sp.edit().putInt("size", v).apply() }

    /** Line thickness in tenths of a dp (8 = 0.8dp). */
    var thickness: Int
        get() = sp.getInt("thickness", 8)
        set(v) { sp.edit().putInt("thickness", v).apply() }

    /** Horizontal fine-tune of the camera position, in dp. */
    var posX: Int
        get() = sp.getInt("posX", 0)
        set(v) { sp.edit().putInt("posX", v).apply() }

    /** Vertical fine-tune of the camera position, in dp. */
    var posY: Int
        get() = sp.getInt("posY", 0)
        set(v) { sp.edit().putInt("posY", v).apply() }

    /** Sensitivity in percent. */
    var sens: Int
        get() = sp.getInt("sens", 100)
        set(v) { sp.edit().putInt("sens", v).apply() }

    var scope: Int
        get() = sp.getInt("scope", SCOPE_ALL)
        set(v) { sp.edit().putInt("scope", v).apply() }

    var glow: Boolean
        get() = sp.getBoolean("glow", true)
        set(v) { sp.edit().putBoolean("glow", v).apply() }

    /** Keep a faint ring visible when no music is playing. */
    var idle: Boolean
        get() = sp.getBoolean("idle", true)
        set(v) { sp.edit().putBoolean("idle", v).apply() }
}
