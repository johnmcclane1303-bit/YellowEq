package com.yellow.eq

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sin

private val BG = 0xFF0B0F17.toInt()
private val CARD = 0xFF121823.toInt()
private val PILL = 0xFF1A2230.toInt()
private val STROKE = 0xFF1F2937.toInt()
private val TXT = 0xFFE8ECF3.toInt()
private val SUB = 0xFF8B95A7.toInt()
private val YELLOW = 0xFFFFD400.toInt()
private val GREEN = 0xFF3DDC84.toInt()
private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

class MainActivity : Activity() {

    private lateinit var p: Prefs
    private val h = Handler(Looper.getMainLooper())

    private lateinit var preview: EqView
    private lateinit var power: PowerButton
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var audioTv: TextView
    private lateinit var micBtn: TextView
    private lateinit var a11yBtn: TextView

    private var anim: ValueAnimator? = null
    private val demo = FloatArray(EqView.NB)

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 1000)
        }
    }

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        p = Prefs(this)
        setContentView(build())
        refreshPreview()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        startDemo()
        h.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        anim?.cancel()
        h.removeCallbacks(ticker)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int): Float = v * resources.displayMetrics.density

    private fun lay(w: Int, hh: Int, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(w, hh, weight)
        l.topMargin = dp(top)
        return l
    }

    private fun rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dpf(r)
        if (stroke > 0) g.setStroke(dp(stroke), strokeColor)
        return g
    }

    private fun tv(text: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun card(title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(CARD, 22, 1, STROKE)
        c.setPadding(dp(16), dp(14), dp(16), dp(16))
        val t = tv(title.uppercase(), 11f, SUB, true)
        t.letterSpacing = 0.15f
        c.addView(t)
        return c
    }

    private fun hasMic(): Boolean =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun isA11y(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val cn = ComponentName(this, EqService::class.java)
        val full = cn.flattenToString()
        val short = cn.flattenToShortString()
        return s.split(':').any { it.equals(full, true) || it.equals(short, true) }
    }

    // ---------------------------------------------------------------- UI building

    private fun build(): View {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        scroll.isVerticalScrollBarEnabled = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(22), dp(18), dp(32))
        scroll.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(tv("Yellow", 26f, YELLOW, true))
        head.addView(tv(" Eq", 26f, TXT, true))
        col.addView(head)
        col.addView(tv("Camera equalizer ring", 13f, SUB), lay(MATCH, WRAP, 2))

        // live preview
        val box = FrameLayout(this)
        box.background = rounded(CARD, 24, 1, STROKE)
        val dot = View(this)
        val dg = GradientDrawable()
        dg.shape = GradientDrawable.OVAL
        dg.setColor(0xFF000000.toInt())
        dg.setStroke(dp(1), 0xFF222B3A.toInt())
        dot.background = dg
        preview = EqView(this)
        box.addView(preview, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        box.addView(dot, FrameLayout.LayoutParams(dp(12), dp(12), Gravity.CENTER))
        val live = tv("LIVE PREVIEW", 10f, SUB, true)
        live.letterSpacing = 0.15f
        val liveLp = FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
        liveLp.setMargins(dp(16), dp(12), 0, 0)
        box.addView(live, liveLp)
        col.addView(box, lay(MATCH, dp(200), 18))

        // power button
        power = PowerButton(this)
        power.setOnClickListener { onPower() }
        val pl = LinearLayout.LayoutParams(dp(150), dp(150))
        pl.gravity = Gravity.CENTER_HORIZONTAL
        pl.topMargin = dp(18)
        col.addView(power, pl)
        statusTitle = tv("", 16f, SUB, true)
        statusTitle.gravity = Gravity.CENTER
        statusTitle.letterSpacing = 0.12f
        statusSub = tv("", 13f, SUB)
        statusSub.gravity = Gravity.CENTER
        col.addView(statusTitle, lay(MATCH, WRAP, 2))
        col.addView(statusSub, lay(MATCH, WRAP, 4))

        // setup
        val setup = card("Setup")
        micBtn = setupRow(
            setup, "1   Microphone permission",
            "Needed to read the music's frequencies. Audio is never recorded or sent anywhere."
        )
        micBtn.setOnClickListener {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
        a11yBtn = setupRow(
            setup, "2   Accessibility service",
            "Lets the line draw over other screens. It does not read your content."
        )
        a11yBtn.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        setup.addView(
            tv(
                "Switch greyed out? Open Settings > Apps > Yellow Eq > top-right menu > Allow restricted settings, then try again.",
                11f, SUB
            ), lay(MATCH, WRAP, 10)
        )
        audioTv = tv("", 11f, SUB)
        setup.addView(audioTv, lay(MATCH, WRAP, 8))
        col.addView(setup, lay(MATCH, WRAP, 18))

        // style
        val styleCard = card("Style")
        styleCard.addView(pillRow(EqView.STYLES, p.style) {
            p.style = it
            refreshPreview()
        }, lay(MATCH, WRAP, 12))
        col.addView(styleCard, lay(MATCH, WRAP, 14))

        // color
        val colorCard = card("Color")
        buildColor(colorCard)
        col.addView(colorCard, lay(MATCH, WRAP, 14))

        // size etc.
        val adj = card("Adjust")
        slider(adj, "Size", 5, 40, p.size, { "$it dp" }) { p.size = it; refreshPreview() }
        slider(adj, "Line thickness", 3, 40, p.thickness, { String.format("%.1f dp", it / 10f) }) {
            p.thickness = it; refreshPreview()
        }
        slider(adj, "Sensitivity", 30, 300, p.sens, { "$it %" }) { p.sens = it; refreshPreview() }
        slider(adj, "Camera position  left / right", -100, 100, p.posX, { "$it" }) { p.posX = it }
        slider(adj, "Camera position  up / down", -60, 60, p.posY, { "$it" }) { p.posY = it }
        adj.addView(
            tv("The ring finds your camera automatically. Use the two position sliders only if it is slightly off.", 11f, SUB),
            lay(MATCH, WRAP, 12)
        )
        col.addView(adj, lay(MATCH, WRAP, 14))

        // scope
        val scopeCard = card("Show on")
        scopeCard.addView(pillRow(Prefs.SCOPES, p.scope) { p.scope = it }, lay(MATCH, WRAP, 12))
        scopeCard.addView(
            tv("Works on its own layer. It never touches or changes your wallpaper.", 11f, SUB),
            lay(MATCH, WRAP, 10)
        )
        col.addView(scopeCard, lay(MATCH, WRAP, 14))

        // options
        val opt = card("Options")
        toggle(opt, "Glow", "Soft light around the line", p.glow) { p.glow = it; refreshPreview() }
        toggle(opt, "Idle ring", "Keep a faint ring when no music plays", p.idle) { p.idle = it; refreshPreview() }
        col.addView(opt, lay(MATCH, WRAP, 14))

        col.addView(
            tv(
                "Yellow Eq only reads the loudness of each frequency to animate the line. Nothing is recorded, stored or uploaded.",
                11f, SUB
            ).also { it.gravity = Gravity.CENTER }, lay(MATCH, WRAP, 22)
        )
        return scroll
    }

    private fun setupRow(parent: LinearLayout, title: String, desc: String): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(title, 14f, TXT, true))
        c.addView(tv(desc, 12f, SUB), lay(MATCH, WRAP, 2))
        val btn = tv("", 13f, BG, true)
        btn.gravity = Gravity.CENTER
        btn.setPadding(dp(14), dp(8), dp(14), dp(8))
        val bl = LinearLayout.LayoutParams(WRAP, WRAP)
        bl.leftMargin = dp(10)
        row.addView(c, lay(0, WRAP, 0, 1f))
        row.addView(btn, bl)
        parent.addView(row, lay(MATCH, WRAP, 14))
        return btn
    }

    private fun setBtn(b: TextView, done: Boolean, label: String) {
        if (done) {
            b.text = "Done"
            b.setTextColor(GREEN)
            b.background = rounded(0x1F3DDC84, 20, 1, GREEN)
        } else {
            b.text = label
            b.setTextColor(BG)
            b.background = rounded(YELLOW, 20)
        }
    }

    private fun pillRow(items: List<String>, selected: Int, onSelect: (Int) -> Unit): View {
        val scroll = HorizontalScrollView(this)
        scroll.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        scroll.addView(row)
        val views = ArrayList<TextView>()

        fun paintAll(sel: Int) {
            for (i in views.indices) {
                val on = i == sel
                views[i].setTextColor(if (on) BG else SUB)
                views[i].background = rounded(if (on) YELLOW else PILL, 20, 1, if (on) YELLOW else STROKE)
            }
        }

        for (i in items.indices) {
            val t = tv(items[i], 13f, SUB, true)
            t.setPadding(dp(14), dp(9), dp(14), dp(9))
            t.setOnClickListener {
                paintAll(i)
                onSelect(i)
            }
            val l = LinearLayout.LayoutParams(WRAP, WRAP)
            l.rightMargin = dp(8)
            row.addView(t, l)
            views.add(t)
        }
        paintAll(selected)
        return scroll
    }

    private fun buildColor(parent: LinearLayout) {
        val colors = intArrayOf(
            0xFFFFD400.toInt(), 0xFFFFFFFF.toInt(), 0xFF00E5FF.toInt(), 0xFF39FF88.toInt(),
            0xFFFF4DA6.toInt(), 0xFFFF3B30.toInt(), 0xFFFF8A00.toInt(), 0xFFB26BFF.toInt()
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<View>()

        fun mark() {
            for (i in views.indices) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(colors[i])
                if (colors[i] == p.color) g.setStroke(dp(3), 0xFF5B6678.toInt())
                views[i].background = g
            }
        }

        for (i in colors.indices) {
            val v = View(this)
            v.setOnClickListener {
                p.color = colors[i]
                mark()
                refreshPreview()
            }
            val l = LinearLayout.LayoutParams(0, dp(34), 1f)
            l.rightMargin = dp(6)
            row.addView(v, l)
            views.add(v)
        }
        mark()
        parent.addView(row, lay(MATCH, WRAP, 14))

        parent.addView(tv("Custom color", 13f, SUB), lay(MATCH, WRAP, 16))
        val hsv = FloatArray(3)
        Color.colorToHSV(p.color, hsv)

        val frame = FrameLayout(this)
        val track = View(this)
        val stops = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        val tg = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, stops)
        tg.cornerRadius = dpf(4)
        track.background = tg
        val tl = FrameLayout.LayoutParams(MATCH, dp(8), Gravity.CENTER_VERTICAL)
        tl.leftMargin = dp(12)
        tl.rightMargin = dp(12)
        frame.addView(track, tl)

        val sb = SeekBar(this)
        sb.max = 360
        sb.progress = hsv[0].toInt().coerceIn(0, 360)
        sb.progressTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        sb.progressBackgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        sb.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                if (!fromUser) return
                p.color = Color.HSVToColor(floatArrayOf(pr.toFloat(), 1f, 1f))
                mark()
                refreshPreview()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        frame.addView(sb, FrameLayout.LayoutParams(MATCH, WRAP))
        parent.addView(frame, lay(MATCH, WRAP, 6))
    }

    private fun slider(
        parent: LinearLayout, label: String, lo: Int, hi: Int, value: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ) {
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val valueTv = tv(fmt(value), 13f, YELLOW, true)
        head.addView(tv(label, 14f, TXT), lay(0, WRAP, 0, 1f))
        head.addView(valueTv)

        val sb = SeekBar(this)
        sb.max = hi - lo
        sb.progress = (value - lo).coerceIn(0, hi - lo)
        sb.progressTintList = ColorStateList.valueOf(YELLOW)
        sb.thumbTintList = ColorStateList.valueOf(YELLOW)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0xFF2A3342.toInt())
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, pr: Int, fromUser: Boolean) {
                val v = pr + lo
                valueTv.text = fmt(v)
                if (fromUser) onChange(v)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(head, lay(MATCH, WRAP, 14))
        parent.addView(sb, lay(MATCH, WRAP, 2))
    }

    private fun toggle(parent: LinearLayout, label: String, desc: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.addView(tv(label, 14f, TXT))
        c.addView(tv(desc, 12f, SUB))
        val sw = Switch(this)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, checked -> onChange(checked) }
        row.addView(c, lay(0, WRAP, 0, 1f))
        row.addView(sw)
        parent.addView(row, lay(MATCH, WRAP, 14))
    }

    // ---------------------------------------------------------------- behaviour

    private fun onPower() {
        if (!hasMic() || !isA11y()) {
            Toast.makeText(this, "Finish the two setup steps first", Toast.LENGTH_SHORT).show()
            return
        }
        p.enabled = !p.enabled
        refresh()
    }

    private fun refresh() {
        val mic = hasMic()
        val a11y = isA11y()
        setBtn(micBtn, mic, "Grant")
        setBtn(a11yBtn, a11y, "Open")
        val ready = mic && a11y
        val on = ready && p.enabled
        power.on = on
        statusTitle.text = if (on) "EQUALIZER ON" else "EQUALIZER OFF"
        statusTitle.setTextColor(if (on) YELLOW else SUB)
        statusSub.text = when {
            !ready -> "Finish the setup below to start"
            on -> "Runs in the background - you can close the app"
            else -> "Tap the button to start"
        }
        audioTv.text = "Status: " + EqService.status
    }

    private fun refreshPreview() {
        preview.configure(p)
        val s = preview.neededSize()
        val l = preview.layoutParams
        if (l != null) {
            l.width = s
            l.height = s
            preview.layoutParams = l
        }
    }

    private fun startDemo() {
        anim?.cancel()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 1000
        a.repeatCount = ValueAnimator.INFINITE
        a.interpolator = LinearInterpolator()
        a.addUpdateListener {
            val t = SystemClock.uptimeMillis() / 1000f
            val env = 0.55f + 0.45f * sin(t * 1.9f)
            for (i in 0 until EqView.NB) {
                val b = 0.5f + 0.5f * sin(t * 4.2f + i * 0.62f)
                val tilt = 1.05f - 0.65f * i / EqView.NB
                demo[i] = (b * b * env * tilt).coerceIn(0f, 1f)
            }
            preview.setTargets(demo)
        }
        a.start()
        anim = a
    }
}
