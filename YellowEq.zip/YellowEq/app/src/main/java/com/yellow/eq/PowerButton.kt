package com.yellow.eq

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** The big round power button on the main screen. */
class PowerButton(ctx: Context) : View(ctx) {

    private val d = ctx.resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()

    var on: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 14f * d

        paint.style = Paint.Style.FILL
        paint.color = if (on) 0xFFFFD400.toInt() else 0xFF161D2B.toInt()
        if (on) paint.setShadowLayer(14f * d, 0f, 0f, 0xFFFFD400.toInt()) else paint.clearShadowLayer()
        c.drawCircle(cx, cy, r, paint)
        paint.clearShadowLayer()

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.2f * d
        paint.color = if (on) 0x88FFD400.toInt() else 0xFF2A3342.toInt()
        c.drawCircle(cx, cy, r + 8f * d, paint)

        paint.color = if (on) 0xFF0B0F17.toInt() else 0xFF7C8699.toInt()
        paint.strokeWidth = 3.4f * d
        paint.strokeCap = Paint.Cap.ROUND
        val ir = r * 0.42f
        rect.set(cx - ir, cy - ir, cx + ir, cy + ir)
        c.drawArc(rect, -60f, 300f, false, paint)
        c.drawLine(cx, cy - ir * 1.1f, cx, cy - ir * 0.1f, paint)
    }
}
