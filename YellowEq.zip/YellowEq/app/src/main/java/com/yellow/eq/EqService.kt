package com.yellow.eq

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.inputmethod.InputMethodManager

/**
 * Background service. It keeps running after the app is closed and draws the
 * equalizer ring as an overlay on top of everything (home, apps, lock screen).
 * It is separate from the wallpaper.
 */
class EqService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: EqService? = null

        @Volatile
        var status: String = "Not running"
    }

    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var km: KeyguardManager
    private lateinit var pm: PowerManager
    private val handler = Handler(Looper.getMainLooper())
    private val analyzer = AudioAnalyzer()
    private val bands = FloatArray(EqView.NB)

    private var view: EqView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var launchers: Set<String> = emptySet()
    private var imePkgs: Set<String> = emptySet()
    private var lastPkg: String? = null
    private var receiverRegistered = false

    private val evalRunnable = Runnable { evaluate() }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post {
            evaluate()
            refreshView()
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            handler.removeCallbacks(evalRunnable)
            handler.postDelayed(evalRunnable, 300)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            val v = view ?: return
            if (!analyzer.running) {
                if (!analyzer.start()) {
                    status = "Audio engine failed: " + (analyzer.lastError ?: "unknown")
                    handler.postDelayed(this, 2000)
                    return
                }
                status = "Running - listening to your music"
            }
            if (analyzer.read(bands)) {
                v.setTargets(bands)
                handler.postDelayed(this, 16)
            } else {
                status = "Audio engine stopped: " + (analyzer.lastError ?: "unknown")
                handler.postDelayed(this, 1500)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager

        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            launchers = packageManager.queryIntentActivities(home, 0)
                .map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) {
        }
        try {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imePkgs = imm.enabledInputMethodList.map { it.packageName }.toSet()
        } catch (e: Exception) {
        }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(screenReceiver, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenReceiver, f)
        }
        receiverRegistered = true
        prefs.sp.registerOnSharedPreferenceChangeListener(prefListener)

        status = "Standby"
        evaluate()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        if (p == "com.android.systemui" || p == "android" || p in imePkgs) return
        if (p != lastPkg) {
            lastPkg = p
            handler.removeCallbacks(evalRunnable)
            handler.postDelayed(evalRunnable, 150)
        }
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        handler.postDelayed({ refreshView() }, 300)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        hideOverlay()
        if (receiverRegistered) {
            try { unregisterReceiver(screenReceiver) } catch (e: Exception) { }
            receiverRegistered = false
        }
        if (::prefs.isInitialized) {
            try { prefs.sp.unregisterOnSharedPreferenceChangeListener(prefListener) } catch (e: Exception) { }
        }
        instance = null
        status = "Not running"
    }

    /** Decides whether the ring should be visible right now. */
    private fun evaluate() {
        if (!::prefs.isInitialized) return
        val on = prefs.enabled && pm.isInteractive
        val locked = km.isKeyguardLocked
        val onHome = lastPkg == null || lastPkg in launchers
        val show = on && when (prefs.scope) {
            Prefs.SCOPE_HOME -> !locked && onHome
            Prefs.SCOPE_LOCK -> locked
            else -> true
        }
        if (show) showOverlay() else hideOverlay()
    }

    private fun showOverlay() {
        if (view != null) {
            refreshView()
            return
        }
        val v = EqView(this)
        v.configure(prefs)
        val l = buildLayout(v)
        try {
            wm.addView(v, l)
            view = v
        } catch (e: Exception) {
            status = "Overlay failed: " + (e.message ?: "")
            return
        }
        status = "Starting audio engine..."
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    private fun hideOverlay() {
        handler.removeCallbacks(tick)
        val v = view
        if (v != null) {
            try { wm.removeView(v) } catch (e: Exception) { }
        }
        view = null
        lp = null
        analyzer.stop()
        if (instance != null) status = "Standby (ring hidden)"
    }

    private fun refreshView() {
        val v = view ?: return
        v.configure(prefs)
        val l = buildLayout(v)
        try { wm.updateViewLayout(v, l) } catch (e: Exception) { }
    }

    private fun buildLayout(v: EqView): WindowManager.LayoutParams {
        val size = v.neededSize()
        val d = resources.displayMetrics.density
        val c = cameraCenter()
        val cx = c.first + prefs.posX * d
        val cy = c.second + prefs.posY * d

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

        val l = lp ?: WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).also { lp = it }

        l.width = size
        l.height = size
        l.gravity = Gravity.TOP or Gravity.START
        l.x = (cx - size / 2f).toInt()
        l.y = (cy - size / 2f).toInt()
        if (Build.VERSION.SDK_INT >= 30) {
            l.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            l.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        return l
    }

    /** Finds the centre of the front-camera cut-out (falls back to top-centre). */
    private fun cameraCenter(): Pair<Float, Float> {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        var cx = dm.widthPixels / 2f
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        val sb = if (id > 0) resources.getDimensionPixelSize(id) else (24 * dm.density).toInt()
        var cy = sb / 2f
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val m = wm.currentWindowMetrics
                cx = m.bounds.width() / 2f
                val rects = m.windowInsets.displayCutout?.boundingRects
                if (rects != null && rects.isNotEmpty()) {
                    val r = rects[0]
                    cx = r.exactCenterX()
                    cy = r.exactCenterY()
                }
            } catch (e: Exception) {
            }
        }
        return Pair(cx, cy)
    }
}
