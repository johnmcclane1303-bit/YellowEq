package com.yellow.eq

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Draws the thin equalizer ring. It is used both for the live overlay around the
 * camera and for the preview inside the app.
 */
class EqView(ctx: Context) : View(ctx) {

    companion object {
        const val NB = 48
        val STYLES = listOf(
            "Fine Spectrum", "Aura Waves", "Orbit", "Peak Bars", "Ribbon",
            "Radial Bars", "Mirror Bars", "Wave Ring", "Pulse Ring", "Dots"
        )
        val COLOR_MODES = listOf("Solid", "Rainbow", "Dual tone")
    }

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val target = FloatArray(NB)
    private val disp = FloatArray(NB)
    private val peaks = FloatArray(NB)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val path = Path()
    private val path2 = Path()
    private val fillPath = Path()
    private val rect = RectF()
    private val matrix = Matrix()

    private var eqStyle = 0
    private var eqColor = 0xFFFFD400.toInt()
    private var colorMode = 0
    private var radius = dp(11f)
    private var thickness = dp(0.8f)
    private var sens = 1f
    private var glow = true
    private var idle = true
    private var lastNs = 0L
    private var spin = 0f
    private var shader: SweepGradient? = null

    fun configure(p: Prefs) {
        eqStyle = p.style.coerceIn(0, STYLES.size - 1)
        eqColor = p.color
        colorMode = p.colorMode.coerceIn(0, COLOR_MODES.size - 1)
        radius = dp(p.size.toFloat())
        thickness = dp(p.thickness / 10f)
        sens = p.sens / 100f
        glow = p.glow
        idle = p.idle
        shader = null
        setLayerType(if (glow) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        shader = null
    }

    private fun spike() = max(dp(8f), radius * 0.9f)

    /** Size (in px) of the square window needed to draw the ring plus its tallest spikes. */
    fun neededSize(): Int =
        (2f * (radius + spike() + thickness + dp(4f)) + dp(if (glow) 14f else 6f)).toInt()

    /** Feed fresh audio levels (0..1 per band). */
    fun setTargets(src: FloatArray) {
        var any = false
        for (i in 0 until NB) {
            val t = (src[i] * sens).coerceIn(0f, 1f)
            target[i] = t
            if (t > 0f) any = true
        }
        if (!any) {
            for (d in disp) if (d > 0f) { any = true; break }
        }
        if (any) postInvalidateOnAnimation()
    }

    private fun gradientColors(): IntArray {
        if (colorMode == 1) {
            return IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 1f, 1f)) }
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(eqColor, hsv)
        val c2 = Color.HSVToColor(floatArrayOf((hsv[0] + 70f) % 360f, hsv[1], hsv[2]))
        return intArrayOf(eqColor, c2, eqColor)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 1f / 60f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.1f)
        lastNs = now
        // fast attack, slower release -> feels tightly locked to the beat
        val fa = 1f - 0.35f.pow(dt * 60f)
        val fd = 1f - 0.86f.pow(dt * 60f)

        var active = false
        var sum = 0f
        for (i in 0 until NB) {
            val t = target[i]
            val d = disp[i]
            var n = d + (t - d) * (if (t > d) fa else fd)
            if (n < 0.004f && t < 0.004f) n = 0f
            disp[i] = n
            sum += n
            var pk = max(n, peaks[i] - dt * 0.6f)
            if (pk < 0.004f) pk = 0f
            peaks[i] = pk
            if (n > 0f || t > 0f || pk > 0f) active = true
        }
        if (active) spin = (spin + dt * (0.03f + 0.15f * (sum / NB))) % 1f

        val showBase = idle || active
        val cx = width / 2f
        val cy = height / 2f

        paint.color = eqColor
        paint.strokeWidth = thickness
        fill.color = eqColor
        if (colorMode == 0) {
            paint.shader = null
            fill.shader = null
        } else {
            var sh = shader
            if (sh == null) {
                sh = SweepGradient(cx, cy, gradientColors(), null)
                shader = sh
            }
            matrix.setRotate(spin * 360f, cx, cy)
            sh.setLocalMatrix(matrix)
            paint.shader = sh
            fill.shader = sh
        }
        if (glow) {
            paint.setShadowLayer(dp(4f), 0f, 0f, eqColor)
            fill.setShadowLayer(dp(4f), 0f, 0f, eqColor)
        } else {
            paint.clearShadowLayer()
            fill.clearShadowLayer()
        }

        when (eqStyle) {
            0 -> fine(c, cx, cy, showBase)
            1 -> aura(c, cx, cy, showBase)
            2 -> orbit(c, cx, cy, showBase)
            3 -> peakBars(c, cx, cy, showBase)
            4 -> ribbon(c, cx, cy, showBase)
            5 -> bars(c, cx, cy, false, showBase)
            6 -> bars(c, cx, cy, true, showBase)
            7 -> wave(c, cx, cy, showBase)
            8 -> pulse(c, cx, cy, showBase)
            else -> dots(c, cx, cy, showBase)
        }

        if (active) postInvalidateOnAnimation() else lastNs = 0L
    }

    // ------------------------------------------------------------ new styles

    /** 120 hairlines, an inner thin ring and falling peak dots. */
    private fun fine(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        val sp = spike()
        val w = paint.strokeWidth
        if (showBase) {
            paint.alpha = 120
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 55
            c.drawCircle(cx, cy, radius - dp(3f), paint)
        }
        val n = 120
        val half = n / 2
        paint.strokeWidth = w * 0.6f
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            val a = i * 2.0 * PI / n - PI / 2
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            if (v >= 0.02f) {
                val s = radius + dp(1f)
                val e = s + v * sp
                paint.alpha = (140 + 115 * v).toInt().coerceIn(0, 255)
                c.drawLine(cx + ca * s, cy + sa * s, cx + ca * e, cy + sa * e, paint)
            }
            val pk = peaks[idx]
            if (pk >= 0.05f) {
                val pr = radius + dp(3f) + pk * sp
                fill.alpha = 220
                c.drawCircle(cx + ca * pr, cy + sa * pr, w * 0.55f, fill)
            }
        }
        paint.strokeWidth = w
        paint.alpha = 255
    }

    /** Three layered, slowly rotating waves (soft "aura" look). */
    private fun aura(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        val w = paint.strokeWidth
        val amps = floatArrayOf(0.95f, 0.70f, 0.50f)
        val alphas = intArrayOf(255, 140, 80)
        val signs = floatArrayOf(1f, 1f, -1f)
        for (l in 0..2) {
            path.reset()
            val dir = if (l % 2 == 0) 1f else -1f
            waveInto(path, cx, cy, radius, sp * amps[l], spin * (0.6f + l * 0.5f) * dir, signs[l])
            paint.alpha = alphas[l]
            paint.strokeWidth = w * (1f - 0.15f * l)
            c.drawPath(path, paint)
        }
        paint.strokeWidth = w
        paint.alpha = 255
    }

    /** Three concentric rings with arcs sized by bass / mid / treble, plus an orbiting dot. */
    private fun orbit(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        val gap = sp * 0.32f
        val w = paint.strokeWidth
        val levels = floatArrayOf(avg(0, 5), avg(6, 22), avg(23, NB - 1))
        for (l in 0..2) {
            val rr = radius + gap * l
            paint.alpha = 55
            c.drawCircle(cx, cy, rr, paint)
            paint.alpha = 255
            rect.set(cx - rr, cy - rr, cx + rr, cy + rr)
            val dir = if (l % 2 == 0) 1f else -1f
            val start = spin * 360f * (l + 1) * dir
            val sweep = 30f + 250f * levels[l].coerceIn(0f, 1f)
            c.drawArc(rect, start, sweep, false, paint)
        }
        val a = spin * 4.0 * 2.0 * PI
        val dr = radius + gap * 2.6f + levels[0] * sp * 0.4f
        fill.alpha = 255
        c.drawCircle(cx + (cos(a) * dr).toFloat(), cy + (sin(a) * dr).toFloat(), w * 2.2f, fill)
        paint.alpha = 255
    }

    /** Bars with a small cap that floats above each bar and falls slowly. */
    private fun peakBars(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        val sp = spike()
        val w = paint.strokeWidth
        if (showBase) {
            paint.alpha = 100
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 255
        }
        val n = 60
        val half = n / 2
        paint.strokeWidth = w * 1.5f
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            val pk = peaks[idx]
            val a = i * 2.0 * PI / n - PI / 2
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            if (v >= 0.02f) {
                paint.alpha = 255
                val e = radius + v * sp
                c.drawLine(cx + ca * radius, cy + sa * radius, cx + ca * e, cy + sa * e, paint)
            }
            if (pk >= 0.04f) {
                val s = radius + pk * sp + dp(2.2f)
                val e = s + dp(1.6f)
                paint.alpha = 200
                c.drawLine(cx + ca * s, cy + sa * s, cx + ca * e, cy + sa * e, paint)
            }
        }
        paint.strokeWidth = w
        paint.alpha = 255
    }

    /** Two waves (outer + inner) with a soft fill between them. */
    private fun ribbon(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        path.reset()
        path2.reset()
        waveInto(path, cx, cy, radius, sp * 0.85f, 0f, 1f)
        waveInto(path2, cx, cy, radius, sp * 0.45f, 0f, -1f)
        fillPath.reset()
        fillPath.fillType = Path.FillType.EVEN_ODD
        fillPath.addPath(path)
        fillPath.addPath(path2)
        fill.alpha = 55
        c.drawPath(fillPath, fill)
        paint.alpha = 255
        c.drawPath(path, paint)
        paint.alpha = 150
        c.drawPath(path2, paint)
        paint.alpha = 255
    }

    // ------------------------------------------------------------ shared helpers

    private fun waveInto(p: Path, cx: Float, cy: Float, base: Float, amp: Float, phase: Float, sign: Float) {
        val m = 144
        for (k in 0 until m) {
            val u = k / m.toFloat()
            var uu = u + phase
            uu -= floor(uu)
            val mm = if (uu < 0.5f) uu * 2f else (1f - uu) * 2f
            val f = mm * (NB - 1)
            val i0 = f.toInt().coerceIn(0, NB - 1)
            val i1 = min(i0 + 1, NB - 1)
            val v = disp[i0] + (disp[i1] - disp[i0]) * (f - i0)
            val rr = base + sign * v * amp
            val a = u * 2.0 * PI - PI / 2
            val x = cx + (cos(a) * rr).toFloat()
            val y = cy + (sin(a) * rr).toFloat()
            if (k == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        p.close()
    }

    private fun avg(from: Int, to: Int): Float {
        var s = 0f
        for (i in from..to) s += disp[i]
        return s / (to - from + 1)
    }

    // ------------------------------------------------------------ classic styles

    private fun bars(c: Canvas, cx: Float, cy: Float, mirror: Boolean, showBase: Boolean) {
        val sp = spike()
        if (showBase) {
            paint.alpha = 110
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 255
        }
        val n = 72
        val half = n / 2
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            if (v < 0.02f) continue
            val a = i * 2.0 * PI / n - PI / 2
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val len = v * sp
            val s = if (mirror) radius - len * 0.5f else radius
            val e = if (mirror) radius + len * 0.5f else radius + len
            c.drawLine(cx + ca * s, cy + sa * s, cx + ca * e, cy + sa * e, paint)
        }
    }

    private fun wave(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        path.reset()
        waveInto(path, cx, cy, radius, spike() * 0.85f, 0f, 1f)
        c.drawPath(path, paint)
    }

    private fun pulse(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        val bass = avg(0, 5)
        val mid = avg(6, 22)
        val hi = avg(23, NB - 1)
        paint.alpha = 70
        c.drawCircle(cx, cy, radius + (hi * 0.6f + mid * 0.4f) * sp, paint)
        paint.alpha = 140
        c.drawCircle(cx, cy, radius + mid * sp * 0.8f, paint)
        paint.alpha = 255
        c.drawCircle(cx, cy, radius + bass * sp * 0.7f, paint)
    }

    private fun dots(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        val sp = spike()
        if (showBase) {
            paint.alpha = 60
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 255
        }
        val n = 48
        val half = n / 2
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            val a = i * 2.0 * PI / n - PI / 2
            val rr = radius + v * sp
            val x = cx + (cos(a) * rr).toFloat()
            val y = cy + (sin(a) * rr).toFloat()
            fill.alpha = (90 + 165 * v).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, thickness * (1f + v) * 1.2f, fill)
        }
    }
}
