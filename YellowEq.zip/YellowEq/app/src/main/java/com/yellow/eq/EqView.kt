package com.yellow.eq

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * Draws the thin equalizer ring. It is used both for the live overlay around the
 * camera and for the preview inside the app.
 */
class EqView(ctx: Context) : View(ctx) {

    companion object {
        const val NB = 48
        val STYLES = listOf("Radial Bars", "Mirror Bars", "Wave Ring", "Pulse Ring", "Dots")
    }

    private val density = ctx.resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val target = FloatArray(NB)
    private val disp = FloatArray(NB)

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val path = Path()

    private var eqStyle = 0
    private var eqColor = 0xFFFFD400.toInt()
    private var radius = dp(11f)
    private var thickness = dp(0.8f)
    private var sens = 1f
    private var glow = true
    private var idle = true
    private var lastNs = 0L

    fun configure(p: Prefs) {
        eqStyle = p.style.coerceIn(0, STYLES.size - 1)
        eqColor = p.color
        radius = dp(p.size.toFloat())
        thickness = dp(p.thickness / 10f)
        sens = p.sens / 100f
        glow = p.glow
        idle = p.idle
        setLayerType(if (glow) LAYER_TYPE_SOFTWARE else LAYER_TYPE_NONE, null)
        invalidate()
    }

    private fun spike() = max(dp(8f), radius * 0.9f)

    /** Size (in px) of the square window needed to draw the ring plus its tallest spikes. */
    fun neededSize(): Int =
        (2f * (radius + spike() + thickness) + dp(if (glow) 14f else 6f)).toInt()

    /** Feed fresh audio levels (0..1 per band). */
    fun setTargets(src: FloatArray) {
        var any = false
        for (i in 0 until NB) {
            val t = (src[i] * sens).coerceIn(0f, 1f)
            target[i] = t
            if (t > 0f) any = true
        }
        if (!any) {
            for (d in disp) if (d > 0f) { any = true; break }
        }
        if (any) postInvalidateOnAnimation()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 1f / 60f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.1f)
        lastNs = now
        // fast attack, slower release -> feels tightly locked to the beat
        val fa = 1f - 0.35f.pow(dt * 60f)
        val fd = 1f - 0.86f.pow(dt * 60f)

        var active = false
        for (i in 0 until NB) {
            val t = target[i]
            val d = disp[i]
            var n = d + (t - d) * (if (t > d) fa else fd)
            if (n < 0.004f && t < 0.004f) n = 0f
            disp[i] = n
            if (n > 0f || t > 0f) active = true
        }

        val showBase = idle || active
        val cx = width / 2f
        val cy = height / 2f

        paint.color = eqColor
        paint.strokeWidth = thickness
        fill.color = eqColor
        if (glow) {
            paint.setShadowLayer(dp(4f), 0f, 0f, eqColor)
            fill.setShadowLayer(dp(4f), 0f, 0f, eqColor)
        } else {
            paint.clearShadowLayer()
            fill.clearShadowLayer()
        }

        when (eqStyle) {
            0 -> bars(c, cx, cy, false, showBase)
            1 -> bars(c, cx, cy, true, showBase)
            2 -> wave(c, cx, cy, showBase)
            3 -> pulse(c, cx, cy, showBase)
            else -> dots(c, cx, cy, showBase)
        }

        if (active) postInvalidateOnAnimation() else lastNs = 0L
    }

    private fun bars(c: Canvas, cx: Float, cy: Float, mirror: Boolean, showBase: Boolean) {
        val sp = spike()
        if (showBase) {
            paint.alpha = 110
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 255
        }
        val n = 72
        val half = n / 2
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            if (v < 0.02f) continue
            val a = i * 2.0 * PI / n - PI / 2
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            val len = v * sp
            val s = if (mirror) radius - len * 0.5f else radius
            val e = if (mirror) radius + len * 0.5f else radius + len
            c.drawLine(cx + ca * s, cy + sa * s, cx + ca * e, cy + sa * e, paint)
        }
    }

    private fun wave(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        val m = 144
        path.reset()
        for (k in 0 until m) {
            val u = k / m.toFloat()
            val mm = if (u < 0.5f) u * 2f else (1f - u) * 2f
            val f = mm * (NB - 1)
            val i0 = f.toInt().coerceIn(0, NB - 1)
            val i1 = min(i0 + 1, NB - 1)
            val v = disp[i0] + (disp[i1] - disp[i0]) * (f - i0)
            val rr = radius + v * sp * 0.85f
            val a = u * 2.0 * PI - PI / 2
            val x = cx + (cos(a) * rr).toFloat()
            val y = cy + (sin(a) * rr).toFloat()
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, paint)
    }

    private fun avg(from: Int, to: Int): Float {
        var s = 0f
        for (i in from..to) s += disp[i]
        return s / (to - from + 1)
    }

    private fun pulse(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        if (!showBase) return
        val sp = spike()
        val bass = avg(0, 5)
        val mid = avg(6, 22)
        val hi = avg(23, NB - 1)
        paint.alpha = 70
        c.drawCircle(cx, cy, radius + (hi * 0.6f + mid * 0.4f) * sp, paint)
        paint.alpha = 140
        c.drawCircle(cx, cy, radius + mid * sp * 0.8f, paint)
        paint.alpha = 255
        c.drawCircle(cx, cy, radius + bass * sp * 0.7f, paint)
    }

    private fun dots(c: Canvas, cx: Float, cy: Float, showBase: Boolean) {
        val sp = spike()
        if (showBase) {
            paint.alpha = 60
            c.drawCircle(cx, cy, radius, paint)
            paint.alpha = 255
        }
        val n = 48
        val half = n / 2
        for (i in 0 until n) {
            val j = if (i < half) i else n - 1 - i
            val idx = (j * NB / half).coerceIn(0, NB - 1)
            val v = disp[idx]
            val a = i * 2.0 * PI / n - PI / 2
            val rr = radius + v * sp
            val x = cx + (cos(a) * rr).toFloat()
            val y = cy + (sin(a) * rr).toFloat()
            fill.color = eqColor
            fill.alpha = (90 + 165 * v).toInt().coerceIn(0, 255)
            c.drawCircle(x, y, thickness * (1f + v) * 1.2f, fill)
        }
    }
}
